﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SinricLibrary.Devices
{
    public class SinricDeviceTypes
    {
        public const string SmartLock = "SmartLock";
        public const string ContactSensor = "ContactSensor";
    }
}
